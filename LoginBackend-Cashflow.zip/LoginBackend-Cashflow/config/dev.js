module.exports = {
    port: 13756,
    mongoURI: 'mongodb+srv://kcfrong:ynFoVZWJKkWbU2E6@cluster0.sie5hym.mongodb.net/loginDB',
};
