module.exports = {
    port: process.env.PORT,
    mongoURI: process.env.MONG_URI,
};